<!--
  Admin POS Main Layout - Professional admin dashboard layout
  Provides sidebar navigation with Vue Router integration
-->

<template>
  <div class="min-h-screen bg-background flex">
    <!-- Desktop Sidebar -->
    <aside
      class="hidden lg:flex bg-background-card border-r border-gray-200 flex-col shadow-sm transition-all duration-300"
      :class="sidebarExpanded ? 'w-56' : 'w-16'"
    >
      <!-- Header -->
      <div class="flex items-center justify-between p-4 border-b border-gray-200">
        <div class="flex items-center space-x-3" v-if="sidebarExpanded">
          <div class="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-600 rounded-lg flex items-center justify-center">
            <UtensilsCrossed class="text-white text-sm" />
          </div>
          <span class="font-semibold text-text truncate">Garbaking Admin</span>
        </div>
        <div v-else class="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-600 rounded-lg flex items-center justify-center mx-auto">
          <UtensilsCrossed class="text-white text-sm" />
        </div>
        <button
          @click="toggleSidebar"
          class="p-1 rounded-md hover:bg-gray-100 transition-colors"
          :class="{ 'ml-auto': !sidebarExpanded }"
        >
          <ChevronLeft class="w-4 h-4 text-text-light transition-transform" :class="{ 'rotate-180': !sidebarExpanded }" />
        </button>
      </div>

      <!-- Navigation -->
      <nav class="flex-1 p-2 overflow-y-auto">
        <div class="space-y-1">
          <router-link
            v-for="item in sidebarItems"
            :key="item.name"
            :to="item.path"
            class="flex items-center px-3 py-2 rounded-lg relative group transition-colors"
            :class="{
              'bg-primary-500 text-white shadow-sm': $route.path === item.path,
              'text-text-light hover:bg-gray-100 hover:text-text': $route.path !== item.path
            }"
          >
            <component
              :is="item.icon"
              class="w-5 h-5 flex-shrink-0"
              :class="{ 'text-white': $route.path === item.path }"
            />
            <span
              v-if="sidebarExpanded"
              class="ml-3 truncate text-sm font-medium"
            >
              {{ item.label }}
            </span>
            <!-- Tooltip for collapsed state -->
            <div
              v-if="!sidebarExpanded"
              class="absolute left-full ml-2 bg-gray-900 text-white px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50"
            >
              {{ item.label }}
            </div>
          </router-link>
        </div>
      </nav>

      <!-- Bottom Actions -->
      <div class="border-t border-gray-200 p-2">
        <div class="space-y-1">
          <button
            class="w-full flex items-center px-3 py-2 rounded-lg text-text-light hover:bg-gray-100 hover:text-text transition-colors group"
          >
            <MessageCircle class="w-5 h-5 flex-shrink-0" />
            <span v-if="sidebarExpanded" class="ml-3 text-sm font-medium">Support</span>
            <div
              v-if="!sidebarExpanded"
              class="absolute left-full ml-2 bg-gray-900 text-white px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50"
            >
              Support
            </div>
          </button>

          <button
            @click="handleLogout"
            :disabled="authStore.isLoading"
            class="w-full flex items-center px-3 py-2 rounded-lg text-text-light hover:bg-red-50 hover:text-red-600 transition-colors group"
            :class="{ 'opacity-50 cursor-not-allowed': authStore.isLoading }"
          >
            <LogOut class="w-5 h-5 flex-shrink-0" />
            <span v-if="sidebarExpanded" class="ml-3 text-sm font-medium">
              {{ authStore.isLoading ? 'Signing out...' : 'Sign Out' }}
            </span>
            <div
              v-if="!sidebarExpanded"
              class="absolute left-full ml-2 bg-gray-900 text-white px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50"
            >
              {{ authStore.isLoading ? 'Signing out...' : 'Sign Out' }}
            </div>
          </button>
        </div>
      </div>
    </aside>

    <!-- Mobile Top Navigation -->
    <div class="lg:hidden fixed top-0 left-0 right-0 bg-background-card border-b border-gray-200 px-4 py-3 flex items-center justify-between z-50 shadow-sm">
      <div class="flex items-center space-x-3">
        <div class="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-600 rounded-lg flex items-center justify-center">
          <UtensilsCrossed class="text-white text-sm" />
        </div>
        <h1 class="text-lg font-semibold text-text">Garbaking</h1>
      </div>
      <button
        @click="showMobileMenu = !showMobileMenu"
        class="p-2 rounded-lg hover:bg-gray-100 transition-colors"
      >
        <Menu class="w-5 h-5 text-text" />
      </button>
    </div>

    <!-- Mobile Menu -->
    <div v-if="showMobileMenu" class="lg:hidden fixed inset-0 bg-black/50 z-50" @click="showMobileMenu = false">
      <div class="fixed top-0 right-0 w-72 h-full bg-background-card shadow-xl" @click.stop>
        <!-- Mobile Menu Header -->
        <div class="flex items-center justify-between p-4 border-b border-gray-200">
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-600 rounded-lg flex items-center justify-center">
              <UtensilsCrossed class="text-white text-sm" />
            </div>
            <span class="font-semibold text-text">Navigation</span>
          </div>
          <button @click="showMobileMenu = false" class="p-1 rounded-md hover:bg-gray-100">
            <X class="w-5 h-5 text-text-light" />
          </button>
        </div>

        <!-- Mobile Menu Navigation -->
        <nav class="flex-1 p-3 overflow-y-auto">
          <div class="space-y-1">
            <router-link
              v-for="item in sidebarItems"
              :key="item.name"
              :to="item.path"
              @click="showMobileMenu = false"
              class="flex items-center px-3 py-3 rounded-lg transition-colors"
              :class="{
                'bg-primary-500 text-white': $route.path === item.path,
                'text-text-light hover:bg-gray-100 hover:text-text': $route.path !== item.path
              }"
            >
              <component :is="item.icon" class="w-5 h-5 flex-shrink-0" />
              <span class="ml-3 font-medium">{{ item.label }}</span>
            </router-link>
          </div>
        </nav>

        <!-- Mobile Menu Bottom Actions -->
        <div class="border-t border-gray-200 p-3">
          <div class="space-y-1">
            <button class="w-full flex items-center px-3 py-3 rounded-lg text-text-light hover:bg-gray-100 hover:text-text transition-colors">
              <MessageCircle class="w-5 h-5 flex-shrink-0" />
              <span class="ml-3 font-medium">Support</span>
            </button>
            <button
              @click="handleLogout"
              :disabled="authStore.isLoading"
              class="w-full flex items-center px-3 py-3 rounded-lg text-text-light hover:bg-red-50 hover:text-red-600 transition-colors"
              :class="{ 'opacity-50 cursor-not-allowed': authStore.isLoading }"
            >
              <LogOut class="w-5 h-5 flex-shrink-0" />
              <span class="ml-3 font-medium">{{ authStore.isLoading ? 'Signing out...' : 'Sign Out' }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Content Area -->
    <main class="flex-1 flex flex-col overflow-hidden">
      <!-- Header -->
      <header class="bg-background-card border-b border-gray-200 px-6 py-4 hidden lg:block shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <h1 class="text-2xl font-bold text-text">{{ currentPageTitle }}</h1>
            <p class="text-text-light text-sm">{{ getCurrentTime() }}</p>
          </div>
          <div class="flex items-center space-x-4">
            <!-- Role indicator -->
            <div v-if="authStore.userRole" class="flex items-center space-x-2">
              <div
                class="w-2 h-2 rounded-full"
                :style="{ backgroundColor: authStore.roleColor }"
              ></div>
              <span class="text-sm text-text-light">{{ authStore.roleDisplayName }}</span>
            </div>

            <!-- Status indicator -->
            <div class="flex items-center space-x-2">
              <div class="w-2 h-2 bg-success-500 rounded-full"></div>
              <span class="text-sm text-text-light">Online</span>
            </div>

            <!-- User info -->
            <div class="flex items-center space-x-2">
              <span class="text-sm text-text">{{ authStore.displayName }}</span>
              <div
                class="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium"
                :style="{ backgroundColor: authStore.roleColor }"
              >
                {{ authStore.displayName.charAt(0).toUpperCase() }}
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Page Content -->
      <div class="flex-1 overflow-auto p-4 lg:p-6 pt-16 lg:pt-6">
        <router-view />
      </div>
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { usePermissions } from '@/composables/usePermissions'
import { useAuthStore } from '@/stores/auth'
import {
  UtensilsCrossed,
  MessageCircle,
  LayoutGrid,
  Receipt,
  Menu as MenuIcon,
  TrendingUp,
  Settings,
  Table2,
  CreditCard,
  FileText,
  Menu,
  X,
  Users,
  ChefHat,
  Gift,
  Plus,
  LogOut,
  ChevronLeft
} from 'lucide-vue-next'

// Reactive state
const showMobileMenu = ref(false)
const sidebarExpanded = ref(true)
const currentTime = ref(new Date())

const route = useRoute()
const router = useRouter()
const permissions = usePermissions()
const authStore = useAuthStore()

// All possible sidebar navigation items with permission requirements
const allSidebarItems = [
  {
    name: 'dashboard',
    path: '/',
    icon: LayoutGrid,
    label: 'Dashboard',
    feature: 'dashboard'
  },
  {
    name: 'orders',
    path: '/orders',
    icon: Receipt,
    label: 'Orders',
    feature: 'orders'
  },
  {
    name: 'new-order',
    path: '/orders/new',
    icon: Plus,
    label: 'New Order',
    feature: 'orders'
  },
  {
    name: 'menu',
    path: '/menu',
    icon: MenuIcon,
    label: 'Menu',
    feature: 'menu-management'
  },
  {
    name: 'analytics',
    path: '/analytics',
    icon: TrendingUp,
    label: 'Analytics',
    feature: 'analytics'
  },
  {
    name: 'users',
    path: '/users',
    icon: Users,
    label: 'Users',
    feature: 'user-management'
  },
  {
    name: 'tables',
    path: '/tables',
    icon: Table2,
    label: 'Tables',
    requireRole: ['MANAGER', 'ADMIN', 'SUPER_ADMIN']
  },
  {
    name: 'payment',
    path: '/payment',
    icon: CreditCard,
    label: 'Payment',
    feature: 'cash-management'
  },
  {
    name: 'receipts',
    path: '/receipts',
    icon: FileText,
    label: 'Reports',
    feature: 'reports'
  },
  {
    name: 'loyalty',
    path: '/loyalty',
    icon: Gift,
    label: 'Loyalty',
    feature: 'loyalty-management'
  },
  {
    name: 'kitchen',
    path: '/kitchen',
    icon: ChefHat,
    label: 'Kitchen',
    feature: 'kitchen-display'
  },
  {
    name: 'settings',
    path: '/settings',
    icon: Settings,
    label: 'Settings',
    feature: 'system-settings'
  }
]

// Filter sidebar items based on user permissions and role
const sidebarItems = computed(() => {
  // Ensure we always return an array
  try {
    if (!permissions || !authStore.isAuthenticated) {
      return []
    }

    return allSidebarItems.filter(item => {
      // Check feature-based access
      if (item.feature) {
        return permissions.canAccessFeatureByName(item.feature)
      }

      // Check role-based access
      if (item.requireRole) {
        return permissions.hasAnyRole(item.requireRole)
      }

      // Default: show if no restrictions
      return true
    })
  } catch (error) {
    console.warn('Error filtering sidebar items:', error)
    return []
  }
})

// Computed properties
const currentPageTitle = computed(() => {
  try {
    const items = sidebarItems.value
    if (!Array.isArray(items) || items.length === 0) {
      return 'Dashboard'
    }
    const currentRoute = items.find(item => item.path === route.path)
    return currentRoute?.label || 'Dashboard'
  } catch (error) {
    console.warn('Error getting current page title:', error)
    return 'Dashboard'
  }
})

// Methods
const getCurrentTime = () => {
  return currentTime.value.toLocaleString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const toggleSidebar = () => {
  sidebarExpanded.value = !sidebarExpanded.value
}

const handleLogout = async () => {
  try {
    // Close mobile menu if open
    showMobileMenu.value = false

    await authStore.logout('User initiated logout')

    // Explicitly redirect to login page
    router.push('/login')
  } catch (error) {
    console.error('Logout error:', error)
    // Force logout even if API call fails
    authStore.clearSession()
    router.push('/login')
  }
}

// Update time every minute
let timeInterval: number

onMounted(() => {
  timeInterval = setInterval(() => {
    currentTime.value = new Date()
  }, 60000)
})

onUnmounted(() => {
  if (timeInterval) {
    clearInterval(timeInterval)
  }
})
</script>

<style scoped>
/* Custom scrollbar */
.overflow-auto::-webkit-scrollbar {
  width: 4px;
}

.overflow-auto::-webkit-scrollbar-track {
  background: #F5F4F1;
}

.overflow-auto::-webkit-scrollbar-thumb {
  background: #CECCC3;
  border-radius: 2px;
}

.overflow-auto::-webkit-scrollbar-thumb:hover {
  background: #ADB5BD;
}

/* Router link active styling */
.router-link-active {
  @apply bg-primary-500 text-white;
}

/* Mobile menu animations */
@media (max-width: 768px) {
  .fixed.right-0 {
    animation: slideInRight 0.3s ease-out;
  }
}

@keyframes slideInRight {
  from {
    transform: translate3d(100%, 0, 0);
    opacity: 0;
  }
  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
}
</style>