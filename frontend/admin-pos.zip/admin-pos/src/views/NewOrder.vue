<!--
  New Order / POS Interface View
  Modern clean design with category navigation and split layout
-->

<template>
  <div class="h-screen flex bg-gray-50">
    <!-- Left Panel - Menu Browser -->
    <div class="flex-1 flex flex-col min-w-0" :class="{ 'hidden lg:flex': showMobileSummary }">
      <!-- App Header -->
      <div class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="flex items-center justify-between">
          <!-- Left: Logo and Title -->
          <div class="flex items-center space-x-4">
            <div class="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </div>
            <div>
              <h1 class="text-xl font-semibold text-gray-900">Restoe - Front Cashier</h1>
              <p class="text-sm text-gray-500">Point of Sale System</p>
            </div>
          </div>

          <!-- Right: Language and Cart Toggle -->
          <div class="flex items-center space-x-4">
            <!-- Language Selector -->
            <div class="flex items-center space-x-2">
              <img src="https://flagcdn.com/w20/gb.png" alt="English" class="w-5 h-5 rounded" />
              <img src="https://flagcdn.com/w20/id.png" alt="Indonesian" class="w-5 h-5 rounded opacity-60" />
            </div>

            <!-- Mobile Cart Toggle -->
            <button
              @click="showMobileSummary = !showMobileSummary"
              class="lg:hidden bg-blue-600 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
            >
              <ShoppingCart class="w-4 h-4" />
              <span>Cart ({{ cartStore.items.length }})</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Navigation and Search Bar -->
      <div class="bg-white border-b border-gray-200 px-6 py-4">
        <div class="flex items-center justify-between mb-4">
          <!-- Search Bar -->
          <div class="relative flex-1 max-w-md">
            <Search class="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              v-model="searchQuery"
              type="text"
              placeholder="Search Your Menu Here"
              class="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <!-- Category Navigation -->
        <div class="grid grid-cols-4 sm:grid-cols-8 gap-2">
          <!-- All Items -->
          <button
            @click="selectedCategory = 'all'"
            :class="[
              'flex flex-col items-center p-2 rounded-lg transition-all duration-200',
              selectedCategory === 'all'
                ? 'bg-gray-100 border-2 border-gray-300'
                : 'bg-white border border-gray-200 hover:bg-gray-50'
            ]"
          >
            <UtensilsCrossed
              :class="[
                'w-5 h-5 mb-1',
                selectedCategory === 'all' ? 'text-gray-600' : 'text-gray-500'
              ]"
            />
            <span
              :class="[
                'text-xs font-medium',
                selectedCategory === 'all' ? 'text-gray-900' : 'text-gray-900'
              ]"
            >
              All Items
            </span>
            <span
              :class="[
                'text-xs',
                selectedCategory === 'all' ? 'text-gray-700' : 'text-gray-500'
              ]"
            >
              {{ menuStore.menuItems.length }} Menu
            </span>
          </button>

          <!-- Lunch (Main Dishes) -->
          <button
            @click="selectedCategory = 'lunch'"
            :class="[
              'flex flex-col items-center p-2 rounded-lg transition-all duration-200',
              selectedCategory === 'lunch'
                ? 'bg-blue-500 border-2 border-blue-600 text-white'
                : 'bg-white border border-gray-200 hover:bg-blue-50'
            ]"
          >
            <Salad
              :class="[
                'w-5 h-5 mb-1',
                selectedCategory === 'lunch' ? 'text-white' : 'text-blue-500'
              ]"
            />
            <span
              :class="[
                'text-xs font-medium',
                selectedCategory === 'lunch' ? 'text-white' : 'text-gray-900'
              ]"
            >
              Main Dishes
            </span>
            <span
              :class="[
                'text-xs',
                selectedCategory === 'lunch' ? 'text-blue-100' : 'text-gray-500'
              ]"
            >
              {{ getCategoryCount('lunch') }} Menu
            </span>
          </button>

          <!-- Appetizers/Starters -->
          <button
            @click="selectedCategory = 'appetizer'"
            :class="[
              'flex flex-col items-center p-2 rounded-lg transition-all duration-200',
              selectedCategory === 'appetizer'
                ? 'bg-green-100 border-2 border-green-300'
                : 'bg-white border border-gray-200 hover:bg-green-50'
            ]"
          >
            <ChefHat
              :class="[
                'w-5 h-5 mb-1',
                selectedCategory === 'appetizer' ? 'text-green-600' : 'text-green-500'
              ]"
            />
            <span
              :class="[
                'text-xs font-medium',
                selectedCategory === 'appetizer' ? 'text-green-900' : 'text-gray-900'
              ]"
            >
              Starters
            </span>
            <span
              :class="[
                'text-xs',
                selectedCategory === 'appetizer' ? 'text-green-700' : 'text-gray-500'
              ]"
            >
              {{ getCategoryCount('appetizer') }} Menu
            </span>
          </button>

          <!-- Desserts -->
          <button
            @click="selectedCategory = 'desserts'"
            :class="[
              'flex flex-col items-center p-2 rounded-lg transition-all duration-200',
              selectedCategory === 'desserts'
                ? 'bg-pink-100 border-2 border-pink-300'
                : 'bg-white border border-gray-200 hover:bg-pink-50'
            ]"
          >
            <Cake
              :class="[
                'w-5 h-5 mb-1',
                selectedCategory === 'desserts' ? 'text-pink-600' : 'text-pink-500'
              ]"
            />
            <span
              :class="[
                'text-xs font-medium',
                selectedCategory === 'desserts' ? 'text-pink-900' : 'text-gray-900'
              ]"
            >
              Desserts
            </span>
            <span
              :class="[
                'text-xs',
                selectedCategory === 'desserts' ? 'text-pink-700' : 'text-gray-500'
              ]"
            >
              {{ getCategoryCount('desserts') }} Menu
            </span>
          </button>

          <!-- Beverages -->
          <button
            @click="selectedCategory = 'beverages'"
            :class="[
              'flex flex-col items-center p-2 rounded-lg transition-all duration-200',
              selectedCategory === 'beverages'
                ? 'bg-purple-100 border-2 border-purple-300'
                : 'bg-white border border-gray-200 hover:bg-purple-50'
            ]"
          >
            <Coffee
              :class="[
                'w-5 h-5 mb-1',
                selectedCategory === 'beverages' ? 'text-purple-600' : 'text-purple-500'
              ]"
            />
            <span
              :class="[
                'text-xs font-medium',
                selectedCategory === 'beverages' ? 'text-purple-900' : 'text-gray-900'
              ]"
            >
              Beverages
            </span>
            <span
              :class="[
                'text-xs',
                selectedCategory === 'beverages' ? 'text-purple-700' : 'text-gray-500'
              ]"
            >
              {{ getCategoryCount('beverages') }} Menu
            </span>
          </button>

          <!-- Desserts -->
          <button
            @click="selectedCategory = 'desserts'"
            :class="[
              'flex flex-col items-center p-2 rounded-lg transition-all duration-200',
              selectedCategory === 'desserts'
                ? 'bg-pink-100 border-2 border-pink-300'
                : 'bg-white border border-gray-200 hover:bg-pink-50'
            ]"
          >
            <Cake
              :class="[
                'w-5 h-5 mb-1',
                selectedCategory === 'desserts' ? 'text-pink-600' : 'text-pink-500'
              ]"
            />
            <span
              :class="[
                'text-xs font-medium',
                selectedCategory === 'desserts' ? 'text-pink-900' : 'text-gray-900'
              ]"
            >
              Desserts
            </span>
            <span
              :class="[
                'text-xs',
                selectedCategory === 'desserts' ? 'text-pink-700' : 'text-gray-500'
              ]"
            >
              {{ getCategoryCount('desserts') }} Menu
            </span>
          </button>



        </div>
      </div>

      <!-- Menu Items Section -->
      <div class="flex-1 bg-white flex flex-col min-h-0">
        <!-- Section Header -->
        <div class="flex-none p-6 pb-4">
          <h2 class="text-2xl font-bold text-gray-900">{{ getCategoryTitle() }}</h2>
        </div>

        <!-- Scrollable Menu Items Grid -->
        <div class="flex-1 overflow-y-auto px-6 pb-6">
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Menu Item Card - Horizontal Layout -->
            <div
              v-for="item in filteredItems"
              :key="item.id"
              class="bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-200 p-4"
            >
              <div class="flex space-x-4">
                <!-- Item Image - Left Side -->
                <div class="w-24 h-24 bg-gray-100 rounded-xl flex-shrink-0 overflow-hidden">
                  <img
                    v-if="item.imageUrl"
                    :src="item.imageUrl"
                    :alt="item.name"
                    class="w-full h-full object-cover"
                  />
                  <div v-else class="w-full h-full flex items-center justify-center">
                    <UtensilsCrossed class="w-8 h-8 text-gray-400" />
                  </div>
                </div>

                <!-- Item Details - Right Side -->
                <div class="flex-1 flex flex-col justify-between min-w-0">
                  <!-- Title and Description -->
                  <div class="mb-3">
                    <h3 class="font-bold text-gray-900 text-xl mb-1 truncate">{{ item.name }}</h3>
                    <p class="text-gray-500 text-sm line-clamp-2 leading-relaxed">{{ item.description }}</p>
                  </div>

                  <!-- Price and Controls Row -->
                  <div class="flex items-center justify-between">
                    <!-- Price - Left -->
                    <div class="text-2xl font-bold text-gray-900">
                      ${{ item.price.toFixed(1) }}
                    </div>

                    <!-- Quantity Controls - Right -->
                    <div class="flex items-center space-x-3">
                      <button
                        @click="decrementQuantity(item.id)"
                        class="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                        :disabled="getItemQuantity(item.id) === 0"
                      >
                        <Minus class="w-4 h-4 text-gray-600" />
                      </button>

                      <span class="text-xl font-semibold text-gray-900 min-w-[2rem] text-center">
                        {{ getItemQuantity(item.id) }}
                      </span>

                      <button
                        @click="incrementQuantity(item)"
                        class="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center transition-colors shadow-lg"
                      >
                        <Plus class="w-5 h-5 text-white font-bold" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Right Panel - Order Summary/Invoice -->
    <div
      class="w-full lg:w-96 flex-shrink-0 bg-white border-l border-gray-200 flex flex-col"
      :class="{
        'hidden lg:flex': !showMobileSummary,
        'fixed inset-0 z-50 lg:relative lg:inset-auto': showMobileSummary
      }"
    >
      <!-- Mobile Close Button -->
      <div v-if="showMobileSummary" class="lg:hidden bg-white border-b border-gray-200 p-4">
        <button
          @click="showMobileSummary = false"
          class="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft class="w-5 h-5" />
          <span>Back to Menu</span>
        </button>
      </div>

      <!-- Invoice Header -->
      <div class="bg-white border-b border-gray-200 p-4 sm:p-6">
        <h2 class="text-lg sm:text-xl font-bold text-gray-900">Invoice</h2>
      </div>

      <!-- Cart Items -->
      <div class="flex-1 overflow-y-auto invoice-section p-4 sm:p-6">
        <div v-if="cartStore.items.length === 0" class="text-center text-gray-500 py-8">
          <div class="mb-4">
            <svg class="w-16 h-16 mx-auto text-gray-300" fill="currentColor" viewBox="0 0 24 24">
              <path d="M7 4V3a1 1 0 011-1h8a1 1 0 011 1v1h3a1 1 0 110 2h-1v11a3 3 0 01-3 3H8a3 3 0 01-3-3V6H4a1 1 0 110-2h3zM9 4h6V3H9v1zm0 4a1 1 0 112 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 112 0v6a1 1 0 11-2 0V8z"/>
            </svg>
          </div>
          <p class="text-lg font-medium mb-2">No items added yet</p>
          <p class="text-sm text-gray-400">Items you add will appear here</p>
        </div>

        <div v-else class="space-y-3">
          <div
            v-for="item in cartStore.items"
            :key="item.menuItem.id"
            class="flex items-start space-x-3 p-4 bg-gray-50 rounded-xl border border-gray-100"
          >
            <!-- Item Image -->
            <div class="w-14 h-14 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
              <img
                v-if="item.menuItem.imageUrl"
                :src="item.menuItem.imageUrl"
                :alt="item.menuItem.name"
                class="w-full h-full object-cover"
              />
              <div v-else class="w-full h-full flex items-center justify-center bg-gray-100">
                <UtensilsCrossed class="w-5 h-5 text-gray-400" />
              </div>
            </div>

            <!-- Item Details -->
            <div class="flex-1 min-w-0">
              <h4 class="font-semibold text-gray-900 text-sm mb-1 leading-tight">{{ item.menuItem.name }}</h4>
              <p class="text-xs text-gray-500 mb-2">${{ item.menuItem.price.toFixed(2) }} each</p>

              <!-- Quantity Controls -->
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <button
                    @click="decrementQuantity(item.menuItem.id)"
                    class="w-6 h-6 rounded-full bg-white border border-gray-300 hover:bg-gray-50 flex items-center justify-center transition-colors"
                  >
                    <Minus class="w-3 h-3 text-gray-600" />
                  </button>
                  <span class="text-sm font-medium text-gray-900 min-w-[1.5rem] text-center">{{ item.quantity }}</span>
                  <button
                    @click="incrementQuantity(item.menuItem)"
                    class="w-6 h-6 rounded-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center transition-colors"
                  >
                    <Plus class="w-3 h-3 text-white" />
                  </button>
                </div>

                <div class="text-right">
                  <div class="text-sm font-bold text-gray-900">${{ (item.menuItem.price * item.quantity).toFixed(2) }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Payment Summary -->
      <div class="bg-white border-t border-gray-200 p-4 sm:p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Payment</h3>

        <div class="space-y-3 mb-6">
          <div class="flex justify-between text-gray-600 text-sm">
            <span>Sub Total</span>
            <span>${{ cartStore.subtotal.toFixed(2) }}</span>
          </div>
          <div class="flex justify-between text-gray-600 text-sm">
            <span>Tax</span>
            <span>${{ cartStore.tax.toFixed(2) }}</span>
          </div>
          <div class="border-t border-gray-200 pt-3">
            <div class="flex justify-between text-lg font-bold text-gray-900">
              <span>Total Payment</span>
              <span>${{ cartStore.total.toFixed(2) }}</span>
            </div>
          </div>
        </div>

        <!-- Payment Method Button -->
        <button
          @click="handleCheckout"
          :disabled="cartStore.items.length === 0"
          class="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-xl transition-colors flex items-center justify-center space-x-2 shadow-lg disabled:shadow-none"
        >
          <div class="w-6 h-6 bg-white bg-opacity-20 rounded flex items-center justify-center">
            <CreditCard class="w-4 h-4" />
          </div>
          <span>Credit Card</span>
        </button>
      </div>
    </div>

    <!-- Customer Information Modal -->
    <div v-if="showCustomerModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div class="bg-gray-800 rounded-lg max-w-md w-full" @click.stop>
        <div class="p-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-xl font-bold text-white">Customer Information</h3>
            <button @click="showCustomerModal = false" class="text-gray-400 hover:text-gray-200">
              <X class="w-6 h-6" />
            </button>
          </div>

          <div class="space-y-4">
            <!-- Customer Name -->
            <div>
              <label class="block text-sm font-medium text-gray-300 mb-2">Customer Name</label>
              <input
                v-model="customerInfo.name"
                type="text"
                placeholder="Enter customer name (optional)"
                class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <!-- Customer Phone -->
            <div>
              <label class="block text-sm font-medium text-gray-300 mb-2">Phone Number</label>
              <input
                v-model="customerInfo.phone"
                type="tel"
                placeholder="Enter phone number (optional)"
                class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <!-- Order Notes -->
            <div>
              <label class="block text-sm font-medium text-gray-300 mb-2">Order Notes</label>
              <textarea
                v-model="orderNotes"
                placeholder="Any special instructions for this order..."
                class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows="3"
              ></textarea>
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="flex space-x-3 mt-6">
            <button
              @click="showCustomerModal = false"
              class="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              @click="proceedToPayment"
              class="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium transition-colors"
            >
              Continue to Payment
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Payment Modal -->
    <div v-if="showPaymentModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div class="bg-gray-800 rounded-lg max-w-md w-full" @click.stop>
        <div class="p-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-xl font-bold text-white">Payment</h3>
            <button @click="showPaymentModal = false" class="text-gray-400 hover:text-gray-200">
              <X class="w-6 h-6" />
            </button>
          </div>

          <!-- Order Summary -->
          <div class="bg-gray-700 rounded-lg p-4 mb-4">
            <div class="flex justify-between text-sm mb-2">
              <span class="text-gray-300">Subtotal:</span>
              <span class="text-gray-100">${{ cartStore.subtotal.toFixed(2) }}</span>
            </div>
            <div class="flex justify-between text-sm mb-2">
              <span class="text-gray-300">Tax:</span>
              <span class="text-gray-100">${{ cartStore.tax.toFixed(2) }}</span>
            </div>
            <div class="border-t border-gray-600 pt-2">
              <div class="flex justify-between font-bold">
                <span class="text-white">Total:</span>
                <span class="text-white text-lg">${{ cartStore.total.toFixed(2) }}</span>
              </div>
            </div>
          </div>

          <!-- Payment Method -->
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-300 mb-3">Payment Method</label>
            <div class="grid grid-cols-3 gap-2">
              <button
                v-for="method in paymentMethods"
                :key="method.value"
                @click="selectedPaymentMethod = method.value"
                :class="[
                  'p-3 rounded-lg border-2 transition-colors text-center',
                  selectedPaymentMethod === method.value
                    ? 'border-blue-500 bg-blue-600 bg-opacity-20'
                    : 'border-gray-600 hover:border-gray-500'
                ]"
              >
                <component :is="method.icon" class="w-6 h-6 mx-auto mb-1" />
                <div class="text-sm text-gray-300">{{ method.label }}</div>
              </button>
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="flex space-x-3">
            <button
              @click="showPaymentModal = false"
              class="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded font-medium transition-colors"
            >
              Back
            </button>
            <button
              @click="completeOrder"
              :disabled="!selectedPaymentMethod || isProcessingOrder"
              class="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded font-medium transition-colors flex items-center justify-center"
            >
              <Loader2 v-if="isProcessingOrder" class="animate-spin w-4 h-4 mr-2" />
              {{ isProcessingOrder ? 'Processing...' : 'Complete Order' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

    <!-- Keyboard Shortcuts Modal -->
    <div v-if="showKeyboardShortcuts" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div class="bg-gray-800 rounded-lg max-w-md w-full" @click.stop>
        <div class="p-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-xl font-bold text-white">Keyboard Shortcuts</h3>
            <button @click="showKeyboardShortcuts = false" class="text-gray-400 hover:text-gray-200">
              <X class="w-6 h-6" />
            </button>
          </div>

          <div class="space-y-3 text-sm">
            <div class="flex justify-between items-center">
              <span class="text-gray-300">Toggle Customer Display</span>
              <kbd class="px-2 py-1 bg-gray-700 rounded text-gray-200">F2</kbd>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-gray-300">Clear Cart</span>
              <kbd class="px-2 py-1 bg-gray-700 rounded text-gray-200">Ctrl + Del</kbd>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-gray-300">Checkout</span>
              <kbd class="px-2 py-1 bg-gray-700 rounded text-gray-200">F12</kbd>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-gray-300">Search Menu</span>
              <kbd class="px-2 py-1 bg-gray-700 rounded text-gray-200">Ctrl + F</kbd>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-gray-300">Show Shortcuts</span>
              <kbd class="px-2 py-1 bg-gray-700 rounded text-gray-200">F1</kbd>
            </div>
          </div>

          <button
            @click="showKeyboardShortcuts = false"
            class="w-full mt-6 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '@/stores/cart'
import { useOrdersStore } from '@/stores/orders'
import { useNotificationStore } from '@/stores/notification'
import { useMenuStore } from '@/stores/menu'
import MenuBrowser from '@/components/MenuBrowser.vue'
import OrderSummary from '@/components/OrderSummary.vue'
import {
  ShoppingCart,
  Trash2,
  X,
  CreditCard,
  Banknote,
  Smartphone,
  Loader2,
  Plus,
  Minus,
  UtensilsCrossed,
  ShoppingBag,
  Truck,
  Monitor,
  MonitorOff,
  Keyboard,
  Search,
  ArrowLeft,
  Coffee,
  Salad,
  Moon,
  Soup,
  Cake,
  Cookie,
  ChefHat,
  Wine
} from 'lucide-vue-next'

// Router and stores
const router = useRouter()
const cartStore = useCartStore()
const ordersStore = useOrdersStore()
const notification = useNotificationStore()
const menuStore = useMenuStore()

// Reactive data
const orderType = ref<'DINE_IN' | 'TAKEAWAY' | 'DELIVERY'>('DINE_IN')
const selectedTable = ref('')
const showMobileSummary = ref(false)
const showCustomerModal = ref(false)
const showPaymentModal = ref(false)
const isProcessingOrder = ref(false)
const showKeyboardShortcuts = ref(false)
const isCustomerDisplayConnected = ref(false)
const searchQuery = ref('')
const selectedCategory = ref('all')

const customerInfo = ref({
  name: '',
  phone: ''
})

const orderNotes = ref('')
const selectedPaymentMethod = ref<'cash' | 'card' | 'mobile' | null>(null)

// Static data
const availableTables = ref([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

const orderTypes = [
  { value: 'DINE_IN', label: 'Dine In', icon: UtensilsCrossed },
  { value: 'TAKEAWAY', label: 'Takeaway', icon: ShoppingBag },
  { value: 'DELIVERY', label: 'Delivery', icon: Truck }
]

const paymentMethods = [
  { value: 'cash', label: 'Cash', icon: Banknote },
  { value: 'card', label: 'Card', icon: CreditCard },
  { value: 'mobile', label: 'Mobile', icon: Smartphone }
]

// Computed properties
const filteredItems = computed(() => {
  // Use real menu data from the menu store
  let items = menuStore.menuItems

  // Filter by category first
  if (selectedCategory.value && selectedCategory.value !== 'all') {
    items = items.filter(item => {
      // Map frontend categories to actual backend category names (French)
      const categoryMap: Record<string, string[]> = {
        breakfast: ['breakfast', 'petit-déjeuner', 'petit déjeuner'],
        lunch: ['plats principaux', 'lunch', 'déjeuner', 'plat principal', 'main course'],
        dinner: ['dinner', 'dîner', 'plats principaux', 'plat principal'],
        soup: ['soup', 'soupe', 'soupes'],
        desserts: ['desserts', 'dessert', 'douceurs'],
        side_dish: ['entrées', 'accompagnements', 'sides', 'side dish'],
        appetizer: ['entrées', 'apéritifs', 'appetizers', 'hors d\'oeuvres'],
        beverages: ['boissons', 'beverages', 'drinks', 'boisson']
      }

      const categoryNames = categoryMap[selectedCategory.value] || []
      const itemCategoryName = item.category?.name?.toLowerCase() || ''

      return categoryNames.some(name =>
        itemCategoryName.includes(name.toLowerCase()) ||
        name.toLowerCase().includes(itemCategoryName)
      )
    })
  }

  // Filter by search query
  if (searchQuery.value.trim()) {
    const query = searchQuery.value.toLowerCase()
    items = items.filter(item =>
      item.name?.toLowerCase().includes(query) ||
      item.description?.toLowerCase().includes(query)
    )
  }

  // Only show available items (backend already filters these, but double-check)
  items = items.filter(item =>
    item.isAvailable !== false &&
    item.isActive !== false
  )

  return items
})

// Methods
const getCategoryTitle = () => {
  const categoryMap: Record<string, string> = {
    all: 'All Items',
    lunch: 'Main Dishes',
    appetizer: 'Starters',
    desserts: 'Desserts',
    beverages: 'Beverages'
  }
  return categoryMap[selectedCategory.value] || 'Menu'
}

const getCategoryCount = (category: string) => {
  if (category === 'all') return menuStore.menuItems.length

  const categoryMap: Record<string, string[]> = {
    lunch: ['plats principaux', 'lunch', 'déjeuner', 'plat principal', 'main course'],
    appetizer: ['entrées', 'apéritifs', 'appetizers', 'hors d\'oeuvres'],
    desserts: ['desserts', 'dessert', 'douceurs'],
    beverages: ['boissons', 'beverages', 'drinks', 'boisson']
  }

  const categoryNames = categoryMap[category] || []
  return menuStore.menuItems.filter(item => {
    const itemCategoryName = item.category?.name?.toLowerCase() || ''
    return categoryNames.some(name =>
      itemCategoryName.includes(name.toLowerCase()) ||
      name.toLowerCase().includes(itemCategoryName)
    )
  }).length
}

const getItemQuantity = (itemId: string) => {
  const cartItem = cartStore.items.find(item => item.menuItem.id === itemId)
  return cartItem ? cartItem.quantity : 0
}

const incrementQuantity = (item: any) => {
  cartStore.addItem(item, 1)
}

const decrementQuantity = (itemId: string) => {
  const cartItem = cartStore.items.find(item => item.menuItem.id === itemId)
  if (cartItem && cartItem.quantity > 1) {
    cartStore.updateItemQuantity(itemId, cartItem.quantity - 1)
  } else if (cartItem) {
    cartStore.removeItem(itemId)
  }
}

const removeFromCart = (itemId: string) => {
  cartStore.removeItem(itemId)
  notification.success('Item Removed', 'Item has been removed from cart')
}

const clearCart = () => {
  if (cartStore.isEmpty) return

  cartStore.clearCart()
  notification.success('Cart Cleared', 'All items have been removed from the cart')
}

const handleCheckout = () => {
  if (cartStore.isEmpty) {
    notification.error('Empty Cart', 'Please add items to your cart before checkout')
    return
  }

  showCustomerModal.value = true
}

// Customer display functions
const toggleCustomerDisplay = () => {
  isCustomerDisplayConnected.value = !isCustomerDisplayConnected.value

  if (isCustomerDisplayConnected.value) {
    // Open customer display window
    const customerDisplayUrl = 'http://localhost:3003'
    window.open(customerDisplayUrl, 'CustomerDisplay', 'width=800,height=600,resizable=yes,scrollbars=yes')
    notification.success('Customer Display', 'Customer display connected')

    // Sync current cart to customer display
    syncCartToCustomerDisplay()
  } else {
    notification.info('Customer Display', 'Customer display disconnected')
  }
}

const syncCartToCustomerDisplay = () => {
  if (isCustomerDisplayConnected.value) {
    // In a real implementation, this would send cart data via WebSocket
    console.log('Syncing cart to customer display:', cartStore.items)
  }
}

const proceedToPayment = () => {
  showCustomerModal.value = false
  showPaymentModal.value = true
}

const completeOrder = async () => {
  if (!selectedPaymentMethod.value) {
    notification.error('Payment Method Required', 'Please select a payment method')
    return
  }

  isProcessingOrder.value = true

  try {
    // Create order data
    const orderData = {
      customerName: customerInfo.value.name || 'Walk-in Customer',
      customerPhone: customerInfo.value.phone || undefined,
      tableNumber: orderType.value === 'DINE_IN' ? selectedTable.value : undefined,
      orderType: orderType.value,
      notes: orderNotes.value || undefined,
      paymentMethod: selectedPaymentMethod.value,
      paymentStatus: 'PAID' as const,
      items: cartStore.items.map(item => ({
        menuItemId: item.menuItem.id,
        quantity: item.quantity,
        unitPrice: item.menuItem.price,
        totalPrice: item.menuItem.price * item.quantity,
        specialInstructions: item.specialInstructions
      })),
      subtotal: cartStore.subtotal,
      tax: cartStore.tax,
      total: cartStore.total,
      status: 'PENDING' as const
    }

    // Submit order
    const order = await ordersStore.createOrder(orderData)

    if (order) {
      // Clear cart and reset form
      cartStore.clearCart()
      resetForm()

      notification.success('Order Created', `Order #${order.orderNumber} has been created successfully`)

      // Navigate to orders page to view the new order
      router.push('/orders')
    }
  } catch (error: any) {
    notification.error('Order Failed', error.message || 'Failed to create order')
  } finally {
    isProcessingOrder.value = false
  }
}

const resetForm = () => {
  customerInfo.value = { name: '', phone: '' }
  orderNotes.value = ''
  selectedPaymentMethod.value = null
  selectedTable.value = ''
  showCustomerModal.value = false
  showPaymentModal.value = false
  showMobileSummary.value = false
}

// Keyboard shortcuts handler
const handleKeyboard = (event: KeyboardEvent) => {
  // Prevent shortcuts when typing in inputs
  if (['input', 'textarea', 'select'].includes((event.target as HTMLElement).tagName.toLowerCase())) {
    return
  }

  switch (event.key) {
    case 'F1':
      event.preventDefault()
      showKeyboardShortcuts.value = true
      break
    case 'F2':
      event.preventDefault()
      toggleCustomerDisplay()
      break
    case 'F12':
      event.preventDefault()
      if (!cartStore.isEmpty) {
        handleCheckout()
      }
      break
    case 'Delete':
      if (event.ctrlKey) {
        event.preventDefault()
        clearCart()
      }
      break
  }
}

// Watch cart changes for real-time sync
watch(
  () => cartStore.items,
  () => {
    syncCartToCustomerDisplay()
  },
  { deep: true }
)

// Lifecycle
onMounted(async () => {
  // Add keyboard event listeners
  document.addEventListener('keydown', handleKeyboard)

  // Initialize customer display if available
  if (window.localStorage.getItem('customerDisplayEnabled') === 'true') {
    isCustomerDisplayConnected.value = true
  }

  // Fetch menu data
  try {
    await menuStore.fetchPublicMenu()
  } catch (error) {
    console.error('Failed to fetch menu:', error)
    notification.error('Error', 'Failed to load menu items')
  }

  // Set default category to all items
  selectedCategory.value = 'all'
})

onUnmounted(() => {
  // Remove keyboard event listeners
  document.removeEventListener('keydown', handleKeyboard)
})
</script>

<style scoped>
.line-clamp-2 {
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

/* Custom scrollbar */
.overflow-y-auto::-webkit-scrollbar {
  width: 6px;
}

.overflow-y-auto::-webkit-scrollbar-track {
  background: #f3f4f6;
}

.overflow-y-auto::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 3px;
}

.overflow-y-auto::-webkit-scrollbar-thumb:hover {
  background: #9ca3af;
}

/* Responsive grid adjustments */
@media (max-width: 640px) {
  .grid-cols-4 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

/* Mobile-specific adjustments */
@media (max-width: 768px) {
  .h-screen {
    height: 100vh;
    height: 100dvh; /* Dynamic viewport height for mobile */
  }

  /* Ensure proper touch targets on mobile */
  button {
    min-height: 44px;
  }
}

/* Smooth scrolling */
.overflow-y-auto {
  scroll-behavior: smooth;
  -webkit-overflow-scrolling: touch;
}

/* Ensure proper flex layout */
.min-h-0 {
  min-height: 0;
}

/* Custom scrollbar for menu items only */
.overflow-y-auto::-webkit-scrollbar {
  width: 8px;
}

.overflow-y-auto::-webkit-scrollbar-track {
  background: #f9fafb;
  border-radius: 4px;
}

.overflow-y-auto::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 4px;
}

.overflow-y-auto::-webkit-scrollbar-thumb:hover {
  background: #9ca3af;
}

/* Hide scrollbar for invoice section */
.invoice-section::-webkit-scrollbar {
  display: none;
}

.invoice-section {
  -ms-overflow-style: none;
  scrollbar-width: none;
}
</style>